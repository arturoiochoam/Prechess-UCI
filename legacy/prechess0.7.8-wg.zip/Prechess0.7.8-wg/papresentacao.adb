with Text_IO; use Text_IO;
with pprechess2; use pprechess2;
with Pvalidade; use Pvalidade;

package body Papresentacao is

procedure Apresentacao is

begin

Ingles:=False; 

Lance_Do_Jogo:=0;
Lances_Da_Pessoa:=0;

Resposta:='s';
  
for a in 1..64 loop
 tabuleiro(a):=0;
end loop;

Numero_B_Inimigo:=2; --Numero de bispos. E' que se tiver 2 bispos no fim do jogo, 1 bispo valera mais
Numero_B_Meu:=2;     --que um cavalo.

tabuleiro(4):=20;   --Dama do computador
tabuleiro(5):=999;
tabuleiro(60):=-20;
tabuleiro(61):=-999;  --Rei da pessoa

tabuleiro(1):=7;               --Essas sao pe�as do programa
tabuleiro(2):=4;
tabuleiro(3):=3;
tabuleiro(6):=3;
tabuleiro(7):=4;
tabuleiro(8):=7;
tabuleiro(9):=1;
tabuleiro(10):=1;
tabuleiro(11):=1;
tabuleiro(12):=1;
tabuleiro(13):=1;
tabuleiro(14):=1;
tabuleiro(15):=1;
tabuleiro(16):=1;

tabuleiro(57):=-7;              --Essas sao pe�as da pessoa.
tabuleiro(58):=-4;
tabuleiro(59):=-3;
tabuleiro(62):=-3;
tabuleiro(63):=-4;
tabuleiro(64):=-7;
tabuleiro(49):=-1;
tabuleiro(50):=-1;
tabuleiro(51):=-1;
tabuleiro(52):=-1;
tabuleiro(53):=-1;
tabuleiro(54):=-1;
tabuleiro(55):=-1;
tabuleiro(56):=-1;

end Apresentacao;

end Papresentacao; --fim do pacote apresentacao.
