
package Papresentacao is

Lances_Da_Pessoa: Integer;

Usaingles:Character;
Tabuleironormal:Boolean:=True;
Usa_Tabuleiro,resposta:character;

Winboard:Boolean:=True;
--Na vers�o para WinBoard isso dever� ser TRUE.
--Por enquanto a vers�o para Linux n�o suporta XBoard.

 procedure Apresentacao;

end Papresentacao;
