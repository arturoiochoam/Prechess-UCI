with Pvalidade; use Pvalidade;
with Text_Io; use Text_Io;

package body pprechess2 is
--Esse pacote contem o procedimento prechess2 que � o programa de xadrez propriamente dito.
--Mas aqui ele � chamado pelo prechess.adb que � interface do usuario e se comporta como programa principal.


Procedure prechess2 is

 i,J,K,L,M,N: Integer:=1;  --Puz isso aqui so para ele nao encher!

  procedure Alinha_Dama_Rei is
  A, Posicao_Dama, Posicao_Rei: Integer:=0;
  begin
     for A in 1..64 loop
      if Tabuleiro(A)=20 then Posicao_Dama:=A;end if;
      if Tabuleiro(A)=999 then Posicao_Rei:=A; end if;
     end loop;
     if Posicao_Dama /= 0 then Tabuleiro(Posicao_Dama):=-3;
      if Validade(Posicao_Dama,Posicao_Rei)=True then Alinha(I,J):=True; else Alinha(I,J):=False; end if;
      Tabuleiro(Posicao_Dama):=20;
     end if; --So para evitar zebra caso nao tenha a Dama!
     if Posicao_DAma /= 0 then Tabuleiro(Posicao_Dama):=-7;
      if Validade(Posicao_Dama,Posicao_Rei)=True then Alinha(I,J):=True; end if;
      Tabuleiro(Posicao_Dama):=20;
     end if;
  end Alinha_Dama_Rei;

 function Dama_Protegida(b:Integer) return boolean is
 --B vai receber a posicao onde estava a dama.
 --Quando esse procedimento for executado n�o haver� mais uma dama em B.
 --Haver� uma peca advers�ria! Veja que n�o foi preciso declarar C.
 Protegida:Boolean;
 begin
  if Tabuleiro(b)>-20 then protegida:=False; else --Isso seria uma peca menor atacando a Dama.
  protegida:=False;
  for C in 1 ..64 loop
    if Validade(C,B)=True and Tabuleiro(C)>0 and Tabuleiro(C)/=999 then
    protegida:=True; --Nao quiz proteger com o Rei so para evitar o pior.
    end if;
  end loop;
  end if;
  return Protegida;
 end Dama_Protegida;

 function torre_Protegida(b:Integer) return boolean is
 Protegida: Boolean;
 begin

  if Tabuleiro(b)>-7 then protegida:=False; else --Isso seria uma peca menor atacando a Torre.
  protegida:=False;
  for C in 1 ..64 loop
    if Validade(C,B)=True and Tabuleiro(C)>0 and Tabuleiro(C)/=999 then
    protegida:=True; --Nao quiz proteger com o Rei so para evitar o pior.
    end if;
  end loop;
  end if;
  return Protegida;
 end Torre_Protegida;

 function Bispo_Protegido(B:Integer) return boolean is
  Protegida:Boolean;
 begin
  if Tabuleiro(b)>-3 then protegida:=False; else --Isso seria uma peca menor atacando a Torre.
  protegida:=False;
  for C in 1 ..64 loop
    if Validade(C,B)=True and Tabuleiro(C)>0 and Tabuleiro(C)/=999 then
    protegida:=True; --Nao quiz proteger com o Rei so para evitar o pior.
    end if;
  end loop;
 end if;
 return Protegida;
 end Bispo_Protegido;

 function Cavalo_Protegido(B:Integer)return boolean is
  Protegida:Boolean;
 begin
  if Tabuleiro(b)>-4 then protegida:=False; else --Isso seria uma peca menor atacando a Torre.
  protegida:=False;
  for C in 1 ..64 loop
    if Validade(C,B)=True and Tabuleiro(C)>0 and Tabuleiro(C)/=999 then
    protegida:=True; --Nao quiz proteger com o Rei so para evitar o pior.
    end if;
  end loop;
  end if;
  return Protegida;
 end Cavalo_Protegido;

 procedure Analize3(i,J,K,L,M,N,Soma3l,Soma2l:integer) is
 begin
 if L /= N then --Isso seguinifica que a peca amecada ficou parada no 2 lance.
    --E' so para ser coerente com a definicao do que chamamos de ameacar.
  if Soma3l - Soma2l=1   then Jogada_ameacaP(I,J):=True; end if;
  if Soma3l - Soma2l=3   then Jogada_ameacaB(I,J):=True; end if;
  if Soma3l - Soma2l=4   then Jogada_ameacaC(I,J):=True; end if;
  if Soma3l - Soma2l=7   then Jogada_ameacaT(I,J):=True; end if;
  if Soma3l - Soma2l=20  then Jogada_ameacaD(I,J):=True; end if;
  if Soma3l - Soma2l=999 then Jogada_ameacaR(I,J):=True; end if;
 end if;
 end Analize3;

 procedure Analize2(i,J,K,L,Soma2l,Soma1l:integer) is
 begin

  if Soma2l - Soma1l=-1   then BackupPeao:=Jogada_PerdeP(I,J); Jogada_PerdeP(I,J):=True; end if;
  if Soma2l - Soma1l=-3  and Bispo_Protegido(L)=false  then Jogada_PerdeB(I,J):=True; end if;
  if Soma2l - Soma1l=-4  and Cavalo_Protegido(L)=false then Jogada_PerdeC(I,J):=True; end if;
  if Soma2l - Soma1l=-7  and Torre_Protegida(L)=false  then Jogada_PerdeT(I,J):=True; end if;
  if Soma2l - Soma1l=-20 and Dama_Protegida(L)=false   then Jogada_PerdeD(I,J):=True; end if;
  if Soma2l - Soma1l=-999 then Jogada_PerdeR(I,J):=True; end if;
 --Essa parte deve ser aprimorada pois nem sempre que der true ai voce efetivamente vai perder o Rei, a Dama
 --Usarei as funcoes Dama_protegida, torre_protegida, etc. :).
  if Lance_Do_Jogo>5 then
    for A in 1..8 loop
      if Tabuleiro(A)=-1 then Jogada_Promove_Humano(I,J):=True; end if;
      if Tabuleiro(65-A)=1 then Jogada_Promove_Maquina(I,J):=True; end if;
      --Essa linha acima deveria estar na analize 1, mas puz aqui para compartilhar o loop.
    end loop;
  end if;
 end Analize2;

 procedure Analize1(i,J,Soma1l,Soma0l:integer) is
 begin
  if Soma1l - Soma0l=1   then Jogada_PegaP(I,J):=True; end if; --Peao
  if Soma1l - Soma0l=3   then Jogada_PegaB(I,J):=True; end if; --Bispo
  if Soma1l - Soma0l=4   then Jogada_PegaC(I,J):=True; end if; --Cavalo
  if Soma1l - Soma0l=7   then Jogada_PegaT(I,J):=True; end if; --Torre
  if Soma1l - Soma0l=20  then Jogada_PegaD(I,J):=True; end if; --Dama
  if Soma1l - Soma0l=999 then Jogada_PegaR(I,J):=True; end if; --Rei
 end Analize1;

 procedure Mate(I,J:Integer) is
 --E' um porcedimento e nao uma funcao pois ele recebe
 --como dado de entrada somente a posicao do tabuleiro.
   Temp1, Temp2: Integer;
   Morre: array(1..64,1..64) of Boolean;
   Exequemate_T: array(1..64,1..64) of Boolean;
 procedure S_Lance(Ii,Jj:Integer)  is --Procedimento dentro do Mate.
  begin
  for kk in 1..64 loop
       if tabuleiro(kk) < 0 then   --Ou seja, se tem uma pe�a da pessoa.
          for ll in 1..64 loop
            if tabuleiro(ll) = 999 then --O uso do and deixaria mais lento!
             if validade(kk,ll)=true then
             Morre(II,JJ):=True;
             --O adversario comeu o Rei do computador!!!
             end if;
            end if;
          end loop;
       end if;
  end loop;
  end S_Lance;

 begin --Incio do Mate.

 Exequemate_T(I,J):=true;

 for ii in 1..64 loop
      if tabuleiro(ii) > 0 then   --Ou seja, se tem uma peca do computador.
          temp1:=tabuleiro(ii);--So para lembrar que peca era.

          for jj in 1..64 loop
            if tabuleiro(jj) <= 0 then
             if validade(ii,jj)=true then

             Morre(Ii,Jj):=False;

             tabuleiro(ii) := 0;      --A pe�a sai, ele comeca a jogar em seu pensamento!
             temp2:=tabuleiro(jj);
             tabuleiro(jj):=temp1; --pronto, jogou!
             --O computador fez uma jogada qualquer possivel.
             S_Lance(iI,Jj);  --Executa o procedimento So_Lance, que e parecido.

             if Morre(iI,Jj)=false then  --Basta 1 para nao ser chequemate!
                Exequemate_T(I,J):=false;
             end if;

             tabuleiro(jj):=temp2;
             tabuleiro(ii):=temp1;--Tudo volta ao normal! Lembre-se, ele esta pensando e nao jogando!

             end if;
            end if;
          end loop;
       end if;
  end loop;

 if Exequemate_T(I,J)=True then Exequemate(I,J):=True;  end if;
 end Mate;



procedure Mate_ele2(I,J:Integer) is
 --E' um porcedimento e nao uma funcao pois ele recebe
 --como dado de entrada somente a posicao do tabuleiro.
 --Esse procedimento serve para acabar com ele enquanto o
 --outro serve para saber se ele ta em mate ou n�o.
   Temp1, Temp2: Integer;
   Morre: array(1..64,1..64) of Boolean;
   Exequemate_T: array(1..64,1..64) of Boolean;
 procedure S_Lance(Ii,Jj:Integer)  is --Procedimento dentro do Mate.
  begin
  for kk in 1..64 loop
       if tabuleiro(kk) > 0 then   --Ou seja, se tem uma pe�a da pessoa.
          for ll in 1..64 loop
             if tabuleiro(ll) = -999 then --O uso de and tornaria o programa mais lento!
               if validade(kk,ll)=true then
                  Morre(II,JJ):=True;
             --O computador come o rei do cara.!!!
               end if;
             end if;
          end loop;
       end if;
  end loop;
  end S_Lance;

 begin --Incio do Mate ele 2.

 Exequemate_T(I,J):=true;

 for ii in 1..64 loop
      if tabuleiro(ii) < 0 then   --Ou seja, se tem uma peca do computador.
          temp1:=tabuleiro(ii);--So para lembrar que peca era.

          for jj in 1..64 loop
            if tabuleiro(jj) >= 0 then  --O uso de and tornaria o programa mais lento!
             if validade(ii,jj)=true then

             Morre(Ii,Jj):=False;

             tabuleiro(ii) := 0;      --A pe�a sai, ele comeca a jogar em seu pensamento!
             temp2:=tabuleiro(jj);
             tabuleiro(jj):=temp1; --pronto, jogou!
             --O computador fez uma jogada qualquer possivel.
             S_Lance(iI,Jj);  --Executa o procedimento So_Lance, que e parecido.

             if Morre(iI,Jj)=false then  --Basta 1 para nao ser chequemate!
                Exequemate_T(I,J):=false;
             end if;

             tabuleiro(jj):=temp2;
             tabuleiro(ii):=temp1;--Tudo volta ao normal! Lembre-se, ele esta pensando e nao jogando!

             end if;
            end if;
          end loop;
       end if;
  end loop;

 if Exequemate_T(I,J)=True then mataele2(I,J):=True;  end if;
 end Mate_ele2;


 w:integer:=0; --Puz isso aqui so para ele nao encher.

 Procedure Terceiro_Lance(i,J,k,L,temporario4,Soma2l:integer) is
 begin
 for m in 1..64 loop
      if tabuleiro(m) > 0 then   --Ou seja, se tem uma pe�a do computador.

         temporario5:=tabuleiro(m);--So para lembrar que pe�a era.
         for n in 1..64 loop
           if tabuleiro(n) <= 0 then
            if validade(m,n)=true then
            tabuleiro(m) := 0;      --A pe�a sai, ele comeca a jogar em seu pensamento!
            temporario6:=tabuleiro(n);
            tabuleiro(n):=temporario5; --pronto, jogou!
            Soma3l:=0;
            for A in 1..64 loop
              Soma3l:=Soma3l + Tabuleiro(A);
            end loop;

            Analize3(i,J,K,L,M,N,Soma3l,Soma2l);

            if N = L and Temporario4=1 and BackupPeao=false then Jogada_PerdeP(I,J):=false; end if;
            --Ou seja, se N (um lugar onde o computador pode jogar) for igual a L
            --(um lugar onde a pessoa teria jogado comendo um peao) ent�o o peao esta protegido.
            --O backupPeao=true e'para saber se estamos falando do mesmo peao.
            --O ultimo que foi visto.

            tabuleiro(n):=temporario6;
            tabuleiro(m):=temporario5;--Tudo volta ao normal! Lembre-se, ele esta pensando e nao jogando!

            end if;
           end if;
         end loop;
      end if;
 end loop;
 end Terceiro_Lance;

 procedure Segundo_Lance(i,J,Soma1l:integer) is
 begin
 BackupPeao:=False; --Isso ta relacionado com o peao estar nao protegido.
 for k in 1..64 loop
      if tabuleiro(k) < 0 then   --Ou seja, se tem uma pe�a da pessoa.
         temporario3:=tabuleiro(k);--So para lembrar que pe�a era.
         for l in 1..64 loop
           if tabuleiro(l) >= 0 then --O uso do And tornaria o programa mais lento!
            if validade(k,l)=true then
            tabuleiro(k) := 0;      --A pe�a sai, ele comeca a jogar em seu pensamento!
            temporario4:=tabuleiro(l);
            tabuleiro(l):=temporario3; --pronto, jogou!
            Soma2l:=0;
            for A in 1..64 loop
              Soma2l:=Soma2l + Tabuleiro(A);
            end loop;

            Analize2(i,J,K,L,Soma2l,Soma1l);
            Terceiro_Lance(i,J,k,L,Temporario4,Soma2l);  --Executa o procedimento Terceiro Lance.

            for A in 1..64 loop
               if Tabuleiro(A)=999 then Posicao_Do_Rei:=A; end if;
            end loop;

            if Validade(L,Posicao_Do_Rei)=True then
               --Esse if acima e' so para nao ficar lento demais!
               --Devo aprimorar para nao ficar lento e jogar bem!!!
               Mate(I,J);

               Expoem_A_Xeque(I,J):=True;
            end if;

            tabuleiro(l):=temporario4;
            tabuleiro(k):=temporario3;--Tudo volta ao normal! Lembre-se, ele esta pensando e nao jogando!

            end if;
           end if;
         end loop;
      end if;
 end loop;
 end Segundo_Lance;

 a,b,c:integer:=0;    --So para nao torrar.


 Begin --Inicio do programa em si, o prechess2. Mas aqui esta como um procedimento chamado
 --pela interface do usuario que se comporta como programa principal.

 --Aqui inicia o jogo. Esse programa por hora sera chamado cada vez que se for jogar.
 --As pe�as da maquina sao positivas e as da pessoa negativas.
 --Peao=1, bispo=3, cavalo=4, torre=7, dama=20, rei=999.
 --De inicio so vou pensar em coisas que comem, sem me preocupar com coisas complicadas como o xeque.
 --Tamb�m n�o vou me preocupar com os movimentos.
 --Qualquer pe�a pode sair de qualquer lugar e ir para qualquer outro que nao tenha uma pe�a do mesmo
 --tipo. O Rei a principio pode ser comido (por enquanto).
 --Depois a funcao validade diz se a jogada � possivel.


 for A in 1..64 loop
   for B in 1..64 loop       --De inicio nenhuma jogada � boa ou ruim.
      Jogada_pegaR(A,B):=False;Jogada_PerdeR(A,B):=false;Jogada_ameacaR(A,B):=False;
      Jogada_PerdeD(A,B):=False;Jogada_PegaD(A,B):=False;Jogada_ameacaD(A,B):=False;
      Jogada_pegaT(A,B):=False;Jogada_ameacaT(A,B):=False;Jogada_PerdeT(A,B):=False;
      Jogada_pegaB(A,B):=False;Jogada_ameacaB(A,B):=False;Jogada_PerdeB(A,B):=False;
      Jogada_pegaC(A,B):=False;Jogada_ameacaC(A,B):=False;Jogada_PerdeC(A,B):=False;
      Jogada_pegaP(A,B):=False;Jogada_ameacaP(A,B):=False;Jogada_PerdeP(A,B):=False;
      Expoem_A_Xeque(A,B):=False; Comerei(A,B):=False;Exequemate(A,B):=False;
      Jogada_Promove_Maquina(A,B):=False; Jogada_Promove_humano(A,B):=False;
      Alinha(A,B):=False;
      MataEle2(A,B):=False;
   end loop;
 end loop;

 for a in 1..8 loop
   for b in 1..8 loop
       quadro(a,b):=0;  --So para zerar quadro.
   end loop;
 end loop;


 --as letras do inicio do alfabeto, a,b,c,d,e,f,g,h.
 --serao sem importancia. Ja apartir do i serao usadas para memorizar
 --as jogadas e serao de vital importancia.

 --Aqui vou contar o numero de bispos.
 --Primeiro o numero de bispos meus.

  for A in 1..64 loop
     if Tabuleiro(A)=3 then
        Numero_B_Meu:=1;
        for B in 1..64 loop
           if Tabuleiro(B)=3 and B /= A then
              Numero_B_Meu:=2;
           end if;
        end loop;
     end if;
  end loop;

 --Agora o numero de bispos da pessoa.

 for A in 1..64 loop
     if Tabuleiro(A)=-999 then Posicao_Do_Rei_Dele:=A; end if;
     if Tabuleiro(A)=-3 then
        Numero_B_Inimigo:=1;
        for B in 1..64 loop
           if Tabuleiro(B)=-3 and B /= A then
              Numero_B_Inimigo:=2;
           end if;
        end loop;
     end if;
  end loop;

 --Aqui o programa vai pensar no seu primeiro lance.
 --Lembre-se que todas os movimentos sao possiveis a nao ser que a funcao validade diga o contrario.



 Soma0l:=0;
 for A in 1..64 loop
 Soma0l:=Soma0l + Tabuleiro(A);
 end loop;

 for i in 1..64 loop
      if tabuleiro(i) > 0 then   --Ou seja, se tem uma pe�a do computador.
         temporario1:=tabuleiro(i);--S� para lembrar que pe�a era.

         for j in 1..64 loop
            if tabuleiro(j) <= 0 then  --O uso do and tornaria o programa mais lento!
             if validade(i,j)=true then
             tabuleiro(i) := 0;      --A pe�a sai, ele comeca a jogar em seu pensamento!
             temporario2:=tabuleiro(j);
             tabuleiro(j):=temporario1; --pronto, jogou!
             Soma1l:=0;
             for A in 1..64 loop
               Soma1l:=Soma1l + Tabuleiro(A);
             end loop;
             Analize1(i,J,Soma1l,Soma0l);

             if Temporario1=20 or Temporario1=999 then
               Alinha_Dama_Rei;
             end if;
             --Isso acima executa um procedimento que da uma resposta true or false.
             --So conta se for de modo que 1 bispo inimigo ficando no lugar da dama
             --pude-se pegar o Rei. A saida e' na variavel alinha(i,j).
             --O if e' como sempre para nao deixar muito lento.

             if Validade(J,Posicao_Do_Rei_Dele)=True then Mate_Ele2(I,J); end if;
            --Isso acima serve para acabar com o jogo.

             Segundo_Lance(i,J,Soma1l);  --Executa o procedimento Segundo_Lance, que e parecido.

             tabuleiro(j):=temporario2;
             tabuleiro(i):=temporario1;--Tudo volta ao normal! Lembre-se, ele esta pensando e nao jogando!
             end if;
            end if;
         end loop;
      end if;
 end loop;

 cc:=0; dd:=0;
 --Isso e' uma pequena sa�da.

 if numero_de_meu_movimento=0 then
    numero_de_meu_movimento:=numero_de_meu_movimento+1;
    if tabuleiro(4)=999 then    --So para saber se esta com as brancas!
      cc:=12; dd:=20; else   
      cc:=13; dd:=21;
    end if;
 end if;

 if numero_de_meu_movimento=1 and cc=0 and dd=0 then
    numero_de_meu_movimento:=numero_de_meu_movimento+1;
    if tabuleiro(4)=999 then
      cc:=15; dd:=23; else
      if tabuleiro(55)/=-3 then --Para nao ter um bispo que come a torre.
          cc:=10; dd:=18;
      else
	  cc:=2; dd:=17;
      end if;
    end if;
 end if;


 --Agora segue uma sequencia que em muito vai definir o estilo de jogo.
 --Note que o n�o expor a Xeque n�o � muito importante uma vez que a maioria dos
 --xeques possiveis s�o sem fundo!

 Somatoria_Tabuleiro:=0;
 for A in 1..64 loop
    Somatoria_Tabuleiro:=Somatoria_Tabuleiro + Tabuleiro(A);
 end loop; --No inicio a soma � zero.

 if Contagem_Empate >= 3 and Somatoria_Tabuleiro>0 then --O valor 3 pode ser ajustado.
    Perigo_Empate:=True; else  --O ">" � para evitar que passe disso sem empatar empatando depois!
    Perigo_Empate:=False;
 end if;

 Zerar_Contagem_Empate:=False;
 Somar_Contagem_Empate:=False;


 if cc=0 or dd=0 then   --Aqui da xeque mate nele!
 for a in 1..64 loop
   for b in 1..64 loop
    if mataele2(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False
    then --A principio pode trocar dama com dama caso esteja em vantagem!
      cc:=A; dd:=B;  --Veja entao que comer a Dama tem preferencia a dar cheque.
    end if;
   end loop;
 end loop;
 end if;


 if cc=0 or dd=0 then   --Esse if e' so para saber se ja nao jogou!
 for a in 1..64 loop    --Aqui come a Dama sem expor a Xeque e sem permetir promo��o.
   for b in 1..64 loop
    if Jogada_PegaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and (Jogada_PerdeD(A,B)=false or Soma0L>0)
    and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar dama com dama caso esteja em vantagem!
      cc:=A; dd:=B;  --Veja entao que comer a Dama tem preferencia a dar cheque.
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come a Dama.
   for b in 1..64 loop
    if Jogada_PegaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and (Jogada_PerdeD(A,B)=false or Soma0L>0)
    and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar dama com dama caso esteja em vantagem!
      cc:=A; dd:=B;  --Veja entao que comer a Dama tem preferencia a dar cheque.
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui se promove.
   for b in 1..64 loop
    if Jogada_Promove_maquina(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and (Jogada_PerdeD(A,B)=false or Soma0L>0)
    and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Isso e' Xeque com ameaca a Dama.
   for b in 1..64 loop
    if Jogada_AmeacaR(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
      and Jogada_PerdeR(A,B)=false and Jogada_PerdeD(A,B)=false and Jogada_PerdeT(A,B)=false and
      Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and Jogada_PerdeP(A,B)=False and
      Jogada_AmeacaD(A,B)  and Exequemate(A,B)=False
    then  -- Ou seja, so vai dar Xeque se nao perder nada mesmo!
      cc:=A; dd:=B;
      Somar_Contagem_Empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Isso e' Xeque com ameaca a Torre.
   for b in 1..64 loop
    if Jogada_AmeacaR(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
      and Jogada_PerdeR(A,B)=false and Jogada_PerdeD(A,B)=false and Jogada_PerdeT(A,B)=false and
      Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and Jogada_PerdeP(A,B)=False
      and Jogada_AmeacaT(A,B)  and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    then  -- Ou seja, so vai dar Xeque se nao perder nada mesmo!
      cc:=A; dd:=B;
      Somar_Contagem_Empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Isso e' Xeque com ameaca ao Bispo.
   for b in 1..64 loop
    if Jogada_AmeacaR(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
      and Jogada_PerdeR(A,B)=false and Jogada_PerdeD(A,B)=false and Jogada_PerdeT(A,B)=false and
      Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and Jogada_PerdeP(A,B)=False
      and Jogada_AmeacaB(A,B)  and Exequemate(A,B)=False
    then  -- Ou seja, so vai dar Xeque se nao perder nada mesmo!
      cc:=A; dd:=B;
      Somar_Contagem_Empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Isso e' Xeque com ameaca a Cavalo.
   for b in 1..64 loop
    if Jogada_AmeacaR(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
      and Jogada_PerdeR(A,B)=false and Jogada_PerdeD(A,B)=false and Jogada_PerdeT(A,B)=false and
      Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and Jogada_PerdeP(A,B)=False
      and Jogada_AmeacaC(A,B)  and Exequemate(A,B)=False
    then  -- Ou seja, so vai dar Xeque se nao perder nada mesmo!
      cc:=A; dd:=B;
      Somar_Contagem_Empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Isso e' Xeque!
   for b in 1..64 loop
    if Jogada_AmeacaR(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
      and Jogada_PerdeR(A,B)=false and Jogada_PerdeD(A,B)=false and Jogada_PerdeT(A,B)=false and
      Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and Jogada_PerdeP(A,B)=False
      and Exequemate(A,B)=False
    then  -- Ou seja, so vai dar Xeque se nao perder nada mesmo!
      cc:=A; dd:=B;
      Somar_Contagem_Empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Torre sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_PegaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    (Jogada_PerdeT(A,B)=False or Soma0L>0) and Exequemate(A,B)=False  and Expoem_A_Xeque(A,B)=False
     and  Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar torre com torre caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Torre podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_PegaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    (Jogada_PerdeT(A,B)=False or Soma0L>0) and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar torre com torre caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Bispo sem expor a xeque.
   for b in 1..64 loop
    if Jogada_PegaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and Jogada_PerdeC(A,B)=False and
    Jogada_PerdeT(A,B)=False and Expoem_A_Xeque(A,B)=False and
    (Jogada_PerdeB(A,B)=False or Soma0L>0) and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar bispo com bispo caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Bispo podendo expor a xeque.
   for b in 1..64 loop
    if Jogada_PegaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and Jogada_PerdeC(A,B)=False and
    Jogada_PerdeT(A,B)=False and Expoem_A_Xeque(A,B)=False and
    (Jogada_PerdeB(A,B)=False or Soma0L>0) and Exequemate(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar bispo com bispo caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Cavalo sem expor a xeque.
   for b in 1..64 loop
    if Jogada_PegaC(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and Jogada_PerdeB(A,B)=False and
    Jogada_PerdeT(A,B)=False and
    (Jogada_PerdeC(A,B)=False or Soma0L>0) and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar cavalo com cavalo caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Cavalo podendo expor a xeque.
   for b in 1..64 loop
    if Jogada_PegaC(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and Jogada_PerdeB(A,B)=False and
    Jogada_PerdeT(A,B)=False and
    (Jogada_PerdeC(A,B)=False or Soma0L>0) and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar cavalo com cavalo caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Bispo perdendo cavalo em circustancias especificas.
   for b in 1..64 loop  --Sem expor a Xeque.
    if Jogada_PegaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and
    (Jogada_PerdeB(A,B)=False or Soma0L>0) and Lance_Do_Jogo > 6 and Numero_B_inimigo=2
     and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar bispo com bispo caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Bispo perdendo cavalo em circustancias especificas.
   for b in 1..64 loop  --Podendo expor a Xeque.
    if Jogada_PegaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    (Jogada_PerdeB(A,B)=False or Soma0L>0) and Lance_Do_Jogo > 6 and Numero_B_inimigo=2
     and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar bispo com bispo caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;


 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui ameaca Dama e torre sem expor a xeque.
   for b in 1..64 loop  --podendo perder peao.
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_AmeacaT(A,B)=True and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Dama e torre podendo expor a xeque.
   for b in 1..64 loop  --podendo perder peao.
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_AmeacaT(A,B)=True and Exequemate(A,B)=False and Jogada_PerdeP(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui ameaca Dama e cavalo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_PerdeP(A,B)=False
    and Jogada_AmeacaC(A,B)=true and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui ameaca Dama e cavalo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_AmeacaC(A,B)=true and Exequemate(A,B)=False and Jogada_PerdeP(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui ameaca Dama e bispo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_AmeacaB(A,B)=True and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_PerdeP(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui ameaca Dama e  bispo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_AmeacaB(A,B)=True and Exequemate(A,B)=False and Jogada_PerdeP(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui ameaca Dama sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_PerdeP(A,B)=False
    and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Dama podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaD(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False
    and Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Torre e Bispo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Jogada_AmeacaB(A,B)=True and Expoem_A_Xeque(A,B)=false
    and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Torre e Bispo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Jogada_AmeacaB(A,B)=True
    and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Torre e cavalo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Jogada_AmeacaC(A,B)=True
    and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Torre e cavalo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Jogada_AmeacaC(A,B)=True
    and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Bispo e cavalo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Jogada_AmeacaC(A,B)=True and Exequemate(A,B)=False
    and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Bispo e cavalo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Jogada_AmeacaC(A,B)=True
    and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;


 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Peao sem expor a xeque!
   for b in 1..64 loop
    if Jogada_PegaP(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False and
    Jogada_PerdeP(A,B)=False
    and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar peao com peao caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui come Peao podendo expor a xeque!
   for b in 1..64 loop
    if Jogada_PegaP(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=False and Jogada_PerdeB(A,B)=False and Jogada_PerdeC(A,B)=False and
    Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then --A principio pode trocar peao com peao caso esteja em vantagem!
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Torre sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Torre podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaT(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(a,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Bispo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=False and
    Jogada_PerdeP(A,B)=False  and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Bispo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaB(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=False and
    Jogada_PerdeP(A,B)=False  and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;


 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui ameaca Cavalo com peao sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaC(A,B)=True and Validade(A,B)=True and Tabuleiro(a)=1 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;


 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Cavalo sem expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaC(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui ameaca Cavalo podendo expor a Xeque.
   for b in 1..64 loop
    if Jogada_AmeacaC(A,B)=True and Validade(A,B)=True and Tabuleiro(a)>0 and Tabuleiro(b)<=0
    and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
    Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
    Jogada_PerdeP(A,B)=false and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=False
    and Jogada_Promove_Humano(A,B)=false
    then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) then
 for a in 1..64 loop    --Aqui joga peao que nao perca nada e nao exponha a Xeque.
   for b in 1..64 loop  --e sem alinhar dama e rei.
     if Validade(A,B)=True and Tabuleiro(A)=1 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
     and Alinha(A,B)=False and Jogada_Promove_Humano(A,B)=False then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca nada e nao exponha a Xeque.
   for b in 1..64 loop  --e sem alinhar dama e rei.
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
     and Alinha(A,B)=False and Jogada_Promove_Humano(A,B)=False then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca nada e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
     and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga peao que nao perca nada e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
     and Jogada_Promove_Humano(A,B)=False and Tabuleiro(A)=1
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if (cc=0 or dd=0) and Perigo_Empate=False  then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca nada podendo expor a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=False
     then
      cc:=A; dd:=B;
      somar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;


 if cc=0 or dd=0  then
 for a in 1..64 loop    --Aqui joga peao n�o perdendo nada podendo expor a Xeque.
   for b in 1..64 loop  --mas que nao alinhe Rei e Dama.
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Alinha(A,B)=false
     and Jogada_Promove_Humano(A,B)=False and Tabuleiro(A)=1
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0  then
 for a in 1..64 loop    --Aqui joga peao n�o perdendo nada podendo expor a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and Jogada_PerdeC(A,B)=false and
     Jogada_PerdeP(A,B)=False and Exequemate(A,B)=False and Alinha(A,B)=false
     and Jogada_Promove_Humano(A,B)=False and Tabuleiro(A)=1
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que perca peao e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and  Jogada_PerdeC(A,B)=false
     and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true; --A ideia � que se vou perder uma pe�a � pouco proavel que empate.
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que perca peao podendo expor a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=false and  Jogada_PerdeC(A,B)=false
     and Exequemate(A,B)=False and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que perca cavalo ou peao e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=False
     and Exequemate(A,B)=False and Exequemate(A,B)=False  and Expoem_A_Xeque(A,B)=False
     and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que perca cavalo ou peao podendo expor  a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false and Jogada_PerdeB(A,B)=False
     and Exequemate(A,B)=False and Exequemate(A,B)=False  and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que perca bispo, cavalo ou peao e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false  and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
     and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que perca bispo, cavalo ou peao podendo expor a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False and
     Jogada_PerdeT(A,B)=false  and Exequemate(A,B)=False
     and Jogada_Promove_Humano(A,B)=false
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca dama e rei e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False
     and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=False
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca dama e rei podendo expor a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False
     and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=False
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca dama e rei e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False
     and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False and Jogada_Promove_Humano(A,B)=False
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca dama e rei podendo expor a Xeque
   for b in 1..64 loop  --e pondedo promover o cara.
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=False and Jogada_PerdeD(A,B)=False
     and Exequemate(A,B)=False and Expoem_A_Xeque(A,B)=False
     then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca rei e nao exponha a Xeque.
   for b in 1..64 loop  --podendo promover o cara
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=false and Exequemate(A,B)=False  and Expoem_A_Xeque(A,B)=False then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca rei e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=false  and Exequemate(A,B)=False  and Expoem_A_Xeque(A,B)=False then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca Rei e n�o exponha a mate.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Exequemate(A,B)=False and jogada_perdeR(A,B)=False  and Expoem_A_Xeque(A,B)=False then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca o Rei e nao exponha a Xeque.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=false  and Expoem_A_Xeque(A,B)=False then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;

 if cc=0 or dd=0 then
 for a in 1..64 loop    --Aqui joga qualquer coisa que nao perca o Rei.
   for b in 1..64 loop
     if Validade(A,B)=True and Tabuleiro(A)>0 and Tabuleiro(b)<=0
     and Jogada_PerdeR(a,B)=false  then
      cc:=A; dd:=B;
      zerar_contagem_empate:=true;
    end if;
   end loop;
 end loop;
 end if;


if cc=0 or dd=0 then
 Cc:=1; Dd:=1;
end if;


 if Zerar_Contagem_Empate=True then contagem_empate:=0; end if;
 if Somar_Contagem_Empate=True and Zerar_Contagem_Empate=False then Contagem_Empate:=Contagem_Empate+1;
 end if;

end prechess2;  --Fim do programa propriamente dito.

end pprechess2;  --Fim do pacote pprechess2.
