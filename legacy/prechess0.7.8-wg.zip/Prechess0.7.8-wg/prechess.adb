with  Ada.Integer_Text_IO,Pvalidade,Pprechess2,Papresentacao;
use   Ada.Integer_Text_IO,Pvalidade,Pprechess2,Papresentacao;

with adagraph; use adagraph; --AdaGraph2000. You must have it to compile!

procedure prechess    is

--No array Board as pe�as positivas s�o as brancas e as negativas s�o aos pretas. Ele � 8X8.
--No array Tabuleiro as pe�as positivas s�o da maquina e as negativas s�o da pessoa. � 1x64.

   menu, sair, virado:boolean:=false;
   board:array(1..8,1..8) of integer;
   mousex1,mousex2,mousey1,mousey2:integer;
   pessoa_com_branca:boolean:=true; --O "go" muda isso!
   jogou,expoem_rei:boolean;
   ultimo_lance_da_engine,lance_da_pessoa:array(1..4) of integer;
   promovido_da_pessoa:character:=' ';
   rei_humano_mexido, torre_humana_A_mexida, torre_humana_h_mexida:boolean:=false;
   A,aa,bb:integer:=1;
   Linha,Coluna,indice,ltonumero,ntoletra:Integer:=1;
   Exequematenele:Boolean;
   Rei60movido,Rei61movido,Torre57movida,Torre64movida:Boolean:=False;
   RoqueHfeito:Boolean:=False;
   casa_inicial_x,casa_inicial_y,casa_final_x,casa_final_y:integer:=3*50-25;
   --Isso esta relacionado com o contorno para mostrar o movimento da pecas!!
   --3 � so para n�o torrar a paciencia!!!!

function validade(ai,aj,bi,bj: in integer) return boolean is

--ai,aj,bi,bj sao numeros de 1 a 8 que recebem x1,y1,x2,y2.

  resultado:boolean;
  c,d:Integer:=1;
  retaL1, retaL2:integer;

  procedure peaoanda(ai,aj,bi,bj: in integer) is   
  begin
     
    if board(ai,aj)=1 and virado=false then 
       if ai=bi and bj - aj =1  then
	  resultado:=true; --1 pulo.
       elsif ai=bi and bj=4 and aj=2 and board(ai,3)=0 then --2 pulos.
          resultado:=true;
       else
	  resultado:=false;
       end if;
    elsif board(ai,aj)=-1 and virado=false then 
       if ai=bi and aj - bj =1 then
	  resultado:=true; --1 pulo.
       elsif ai=bi and bj=5 and aj=7 and board(ai,6)=0 then --2 pulos.
          resultado:=true;
       else
	  resultado:=false; 
       end if; 
    elsif board(ai,aj)=1 and virado=true then 
       if ai=bi and bj - aj =-1  then
	  resultado:=true; --1 pulo.
       elsif ai=bi and bj=5 and aj=7 and board(ai,6)=0 then --2 pulos.
          resultado:=true;
       else
	  resultado:=false;
       end if;
    else --board=-1 virado=true.
       if ai=bi and aj - bj =-1 then
	  resultado:=true; --1 pulo.
       elsif ai=bi and bj=4 and aj=2 and board(ai,3)=0 then --2 pulos.
          resultado:=true;
       else
	  resultado:=false; 
       end if; 
    end if;
  end peaoanda;

--Mas por hora nao vou ensinar a comer o peao desse jeito.
--Quando um deles der dois pulos.

  procedure peaocome(ai,aj,bi,bj: in integer) is
  begin
    if board(ai,aj)=1 and virado=false then
       if bj - aj =1 and (bi -ai =1 or bi -ai = -1) then resultado:=true; else resultado:=false; end if;
    elsif board(ai,aj)=-1 and virado=false then
       if aj - bj =1 and (bi -ai =1 or bi -ai = -1) then resultado:=true; else resultado:=false; end if;
    elsif board(ai,aj)=1 and virado=true then
       if bj - aj =-1 and (bi -ai =1 or bi -ai = -1) then resultado:=true; else resultado:=false; end if;
    else --board=-1, virada=true.
       if aj - bj =-1 and (bi -ai =1 or bi -ai = -1) then resultado:=true; else resultado:=false; end if;    
    end if;
  end peaocome;

  procedure peaopassant(ai,aj,bi,bj: in integer) is
  begin
      peaocome(ai,aj,bi,bj);
      --Em principio se comporta como quem vai comer.
      --Mas � preciso que aja uma peao inimigo validando.
      if board(bi,aj)*board(ai,aj)/=-1 then
	 resultado:=false;
      end if;
      --Mas � preciso que tenha vindo no ultimo lance.
	
      if ultimo_lance_da_engine(3)/=bi or ultimo_lance_da_engine(4)/=aj or 
      abs(ultimo_lance_da_engine(4)-ultimo_lance_da_engine(2))/=2 
      --A linha acima � para garantir os 2 pulos!
      then
	        resultado:=false;
      end if;
  end peaopassant;

  procedure peao(ai,aj,bi,bj: in integer)  is
  begin
   if board(bi,bj) = 0 then
       if ai=bi then
            peaoanda(ai,aj,bi,bj); 
       else
	    peaopassant(ai,aj,bi,bj);
       end if;
   else
    peaocome(ai,aj,bi,bj);
   end if;
  end peao;

  procedure bispo(ai,aj,bi,bj: in integer)  is --N�o uso o valor 3 pois o procedimento dama tamb�m chamara isso.
    soma, diferenca: integer:=0;  --Atribui zero para o compilador nao reclamar.
  begin            --Eu vou ter que ver se existe pe�as no meio!
                   --� mais ou menos parecido com o procedimento torre, talvez seja mais claro la.
                   --Aqui ele vai procurar por pe�as intermediarias.

   retaL1:=0;retaL2:=0;
   soma:=ai + aj;      --Tanto faz usar a ou b.
   diferenca:=ai - aj; --Se mudasse para aj - ai deveria mudar tamb�m ai em baixo.

    for e in 1..8 loop
       if soma - e >=1 and soma - e <= 8 then   --&
         if board(soma - e, e) /= 0 and ((aj < e and e < bj) or (aj > e and e > bj))
         --soma - e poderia tar assumindo valores nao permitidos. Dai o if &
         then        --Poderia usar ai e bi, da na mesma.
         retaL1:=1;
         end if;
       end if;
    end loop;

    for e in 1..8 loop
       if diferenca + e >=1 and diferenca + e <= 8 then
         if board(diferenca + e,e) /=0 and ((aj < e and e < bj) or (aj > e and e > bj)) then
         --Tive duvida quando ao dife + e.
         retaL2:=1;
         end if;
       end if;
    end loop;


   if (aj + ai = bj + bi and retaL1 = 0) or  (aj - ai = bj - bi and retaL2 = 0) then
    resultado:=true;
   else
    resultado:=false;
   end if;

  end bispo;

  procedure cavalo(ai,aj,bi,bj: in integer)  is 
  begin                
                      

     if ((bj - aj)**2 = 4 and (bi - ai)**2 = 1) or ((bj - aj)**2 = 1 and (bi - ai)**2 = 4) then
     --Acima o **2 e' ao quadrado, usei isso para sumir com o sinal mantendo a simetria,
     --modulo faria o mesmo.
          resultado:=true;
     else resultado:=false;
     end if;
  end cavalo;

  procedure torre(ai,aj,bi,bj: in integer)  is  --N�o usar o valor 7 pois o procedimento dama tambem chamara isso.
  retaI,retaJ:integer;
  begin             --Eu vou ter que ver se existe pe�as no meio!
       --Essa parte vai ver se existe intermediarios.
       --Dire��o I.
       retaI:=0; retaJ:=0;
       for c in 1..8 loop
         if board(ai,c) /= 0 and ((aj < c and c < bj) or (bj < c  and c < aj)) then
          retaI:=1;
         end if;
       end loop;       --Ta havendo um problema, a torre nao ta comendo.
       --Direcao J.
       for c in 1..8 loop
         if board(c,aj) /= 0 and ((ai < c and c < bi) or (bi < c and c < ai)) then
          retaJ:=1;
         end if;
       end loop;
       --Essa parte de baixo autoriza o jogo se tiverem alinhados e nao houver intermediarios
       if bj = aj  and retaJ=0 then
       resultado:=true; else
            if bi = ai and retaI=0 then
            resultado:=true; else
            resultado:=false;
            end if;
       end if;
  end torre;

  procedure dama(ai,aj,bi,bj: in integer)  is  --Esse provavelmente e' o procedimento mais facil
  begin
    bispo(ai,aj,bi,bj);
    if resultado=false then
    torre(ai,aj,bi,bj);
    end if;
  end dama;

  procedure reinormal(ai,aj,bi,bj: in integer)  is  --Nao me preocupo com o Rei nao poder ser exposto a xeque.
  begin              
     if ((bj - aj = 0) or (bj -aj)**2 =1) and ((bi - ai = 0) or (bi -ai)**2 =1) then
     resultado:=true; else
     resultado:=false;     --Tambem aqui nao me preocupo com Roque.
     end if;
  end reinormal;

  procedure reiroque(ai,aj,bi,bj: in integer)  is
  begin
    resultado:=true;
    if aj/=bj then resultado:=false; end if;
    if aj/=1 and aj/=8 then resultado:=false; end if;
    if rei_humano_mexido=true then resultado:=false; end if;
    if virado=false then
       if bi=7 and torre_humana_h_mexida=true then resultado:=false; end if;
       if bi=3 and torre_humana_a_mexida=true then resultado:=false; end if;
    else
       if bi=2 and torre_humana_h_mexida=true then resultado:=false; end if;
       if bi=6 and torre_humana_a_mexida=true then resultado:=false; end if;
       --Cuidado, as letras est�o referenciadas nas pecas brancas e n�o na pessoa.
    end if;
    if bi=7 and (board(7,bj)/=0 or board(6,bj)/=0) then resultado:=false; end if;
    if bi=3 and (board(2,bj)/=0 or board(3,bj)/=0 or board(4,bj)/=0) then resultado:=false; end if;
    if bi=2 and (board(2,bj)/=0 or board(3,bj)/=0) then resultado:=false; end if;
    if bi=6 and (board(5,bj)/=0 or board(6,bj)/=0 or board(7,bj)/=0) then resultado:=false; end if;
  end reiroque;

  procedure rei(ai,aj,bi,bj: in integer)  is  
  begin
   if abs(bi-ai)=2 then
      reiroque(ai,aj,bi,bj);
   else
      reinormal(ai,aj,bi,bj);
   end if;	   
  end rei;


  begin  --Funcao Validade

  --Abaixo havia originalmente um case, mas ele nao funcionou por razoes um tanto desconhecidas.

  if board(ai,aj)=1    then peao(ai,aj,bi,bj);   end if;
  if board(ai,aj)=-1   then peao(ai,aj,bi,bj);   end if;
  if board(ai,aj)=3    then bispo(ai,aj,bi,bj);  end if;
  if board(ai,aj)=-3   then bispo(ai,aj,bi,bj);  end if;
  if board(ai,aj)=4    then cavalo(ai,aj,bi,bj); end if;
  if board(ai,aj)=-4   then cavalo(ai,aj,bi,bj); end if;
  if board(ai,aj)=7    then torre(ai,aj,bi,bj);  end if;
  if board(ai,aj)=-7   then torre(ai,aj,bi,bj);  end if;
  if board(ai,aj)=20   then dama(ai,aj,bi,bj);   end if;
  if board(ai,aj)=-20  then dama(ai,aj,bi,bj);   end if;
  if board(ai,aj)=999  then rei(ai,aj,bi,bj);    end if;
  if board(ai,aj)=-999 then rei(ai,aj,bi,bj);    end if;

  if board(Ai,aj)*board(Bi,bj) > 0 then resultado:=False; end if; --So para ter certeza que nao joga
  --em casa com pe�a da mesma cor
  if board(Ai,aj)=0 or (Ai=Bi and Aj=Bj) then Resultado:=False; end if; 
  return resultado;
end validade;  


procedure contorno_vermelho(x,y:integer) is
--Esse procedimento desenha um contorno verde
--na parte superior e laterais duma casa cujo centro �
--x,y.
begin
draw_line(x-23,y-23,x-23,y+23,light_magenta);
draw_line(x+23,y-23,x+23,y+23,light_magenta);
draw_line(x-23,y+23,x+23,y+23,light_magenta);
draw_line(x-24,y-24,x-24,y+24,light_magenta);
draw_line(x+24,y-24,x+24,y+24,light_magenta);
draw_line(x-24,y+24,x+24,y+24,light_magenta);
draw_line(x-24,y-24,x+24,y-24,light_magenta);
end contorno_vermelho;

procedure apaga_contorno_vermelho_brancas(x,y:integer) is
begin
draw_line(x-23,y-23,x-23,y+23,white);
draw_line(x+23,y-23,x+23,y+23,white);
draw_line(x-23,y+23,x+23,y+23,white);
draw_line(x-24,y-24,x-24,y+24,light_gray);
draw_line(x+24,y-24,x+24,y+24,light_gray);
draw_line(x-24,y+24,x+24,y+24,light_gray);
draw_line(x-24,y-24,x+24,y-24,light_gray);
end apaga_contorno_vermelho_brancas;

procedure apaga_contorno_vermelho_pretas(x,y:integer) is
begin
draw_line(x-23,y-23,x-23,y+23,light_gray);
draw_line(x+23,y-23,x+23,y+23,light_gray);
draw_line(x-23,y+23,x+23,y+23,light_gray);
draw_line(x-24,y-24,x-24,y+24,light_gray);
draw_line(x+24,y-24,x+24,y+24,light_gray);
draw_line(x-24,y+24,x+24,y+24,light_gray);
draw_line(x-24,y-24,x+24,y-24,light_gray);
end apaga_contorno_vermelho_pretas;


procedure apaga_contorno_vermelho(x,y:integer) is
begin
  if (x=25 or x=125 or x=225 or x=325 or x=425) and (y=25 or y=125 or y=225 or y=325 or y=425)
  then apaga_contorno_vermelho_pretas(x,y); 
  elsif (x=75 or x=175 or x=275 or x=375 or x=475) and (y=75 or y=175 or y=275 or y=375 or y=475)
  then apaga_contorno_vermelho_pretas(x,y); 
  else
  apaga_contorno_vermelho_brancas(x,y);
  end if;
end apaga_contorno_vermelho;


procedure limpa_casa_preta(x,y:integer) is
begin
draw_box(x-24,y-24,x+24,y+24,light_gray,true);	
end limpa_casa_preta;

procedure limpa_casa_branca(x,y:integer) is
begin
draw_box(x-24,y-24,x+24,y+24,white,true);
end limpa_casa_branca;

procedure limpa_casa(x,y:integer) is
begin

if (x=25 or x=125 or x=225 or x=325 or x=425) and (y=25 or y=125 or y=225 or y=325 or y=425)
then limpa_casa_preta(x,y); 
elsif (x=75 or x=175 or x=275 or x=375 or x=475) and (y=75 or y=175 or y=275 or y=375 or y=475)
then limpa_casa_preta(x,y); 
else
 limpa_casa_branca(x,y);
end if;
end limpa_casa;

procedure peao_preto(x,y:integer) is
--Esse procedimento cria um peao numa casa cujo centro e' x,y
begin

draw_circle(x,y+3,8,yellow);
draw_box(x-11,y-24,x+11,y-15,yellow);
draw_line(x-4,y-5,x-4,y-15,yellow);
draw_line(x+4,y-5,x+4,y-15,yellow);
flood_fill(x,y+3);
flood_fill(x-10,y-23);
flood_fill(x-3,y-14);

end peao_preto;

procedure peao_branco(x,y:integer) is
--Esse procedimento cria um peao numa casa cujo centro e' x,y
begin

draw_circle(x,y+3,8,light_blue);
draw_box(x-11,y-24,x+11,y-15,light_blue);
draw_line(x-4,y-5,x-4,y-15,light_blue);
draw_line(x+4,y-5,x+4,y-15,light_blue);
flood_fill(x,y+3,white);
flood_fill(x-10,y-23,white);
flood_fill(x-3,y-14,white);

end peao_branco;


procedure bispo_preto(x,y:integer) is
begin
draw_box(x-12,y-23,x+12,y-20,yellow); --Base.
draw_line(x,y-20,x-15,y,yellow);
draw_line(x-15,y,x,y+20,yellow);
draw_line(x,y-20,x+15,y,yellow);
draw_line(x+15,y,x+8,y+10,yellow);
draw_line(x+8,y+10,x+2,y+2,yellow);
draw_line(x+2,y+2,x-1,y+6,yellow);
draw_line(x-1,y+6,x+4,y+14,yellow);
draw_line(x+4,y+14,x,y+20,yellow);
flood_fill(x,y);
flood_fill(x,y-21);
end bispo_preto;

procedure bispo_branco(x,y:integer) is
begin
draw_box(x-12,y-23,x+12,y-20,light_blue); --Base.
draw_line(x,y-20,x-15,y,light_blue);
draw_line(x-15,y,x,y+20,light_blue);
draw_line(x,y-20,x+15,y,light_blue);
draw_line(x+15,y,x+8,y+10,light_blue);
draw_line(x+8,y+10,x+2,y+2,light_blue);
draw_line(x+2,y+2,x-1,y+6,light_blue);
draw_line(x-1,y+6,x+4,y+14,light_blue);
draw_line(x+4,y+14,x,y+20,light_blue);
flood_fill(x,y,white);
flood_fill(x,y-21,white);
end bispo_branco;

procedure dama_preto(x,y:integer) is
--Esse procedimento cria uma dama numa casa cujo centro e' x,y
begin

draw_line(x-12,y-23,x+12,y-23,yellow); --Base da dama.
draw_line(x-12,y-23,x-23,y+12,yellow); --lado esquerdo da coroa.
draw_line(x+12,y-23,x+23,y+12,yellow); --lado direito da coroa.
draw_line(x-23,y+12,x-11,y-5,yellow);
draw_line(x+23,y+12,x+11,y-5,yellow);
draw_line(x+11,y-5,x+6,y+12,yellow);
draw_line(x-11,y-5,x-6,y+12,yellow);
draw_line(x+6,y+12,x,y-5,yellow);
draw_line(x-6,y+12,x,y-5,yellow);
flood_fill(x,y-6);
end dama_preto;

procedure dama_branco(x,y:integer) is
--Esse procedimento cria uma dama numa casa cujo centro e' x,y
begin

draw_line(x-12,y-23,x+12,y-23,light_blue); --Base da dama.
draw_line(x-12,y-23,x-23,y+12,light_blue); --lado esquerdo da coroa.
draw_line(x+12,y-23,x+23,y+12,light_blue); --lado direito da coroa.
draw_line(x-23,y+12,x-11,y-5,light_blue);
draw_line(x+23,y+12,x+11,y-5,light_blue);
draw_line(x+11,y-5,x+6,y+12,light_blue);
draw_line(x-11,y-5,x-6,y+12,light_blue);
draw_line(x+6,y+12,x,y-5,light_blue);
draw_line(x-6,y+12,x,y-5,light_blue);
flood_fill(x,y-6,white);
end dama_branco;


procedure torre_preto(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,yellow); --Base da torre.
draw_line(x-12,y-23,x-12,y+12,yellow); --lado esquerdo.
draw_line(x+12,y-23,x+12,y+12,yellow); --lado direito.
draw_line(x-12,y+12,x,y+12,yellow);
draw_line(x,y+12,x,y+5,yellow);
draw_line(x,y+5,x+7,y+5,yellow);
draw_line(x+7,y+5,x+7,y+12,yellow);
draw_line(x+7,y+12,x+12,y+12,yellow);
flood_fill(x,y);
end torre_preto;

procedure torre_branco(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,light_blue); --Base da torre.
draw_line(x-12,y-23,x-12,y+12,light_blue); --lado esquerdo.
draw_line(x+12,y-23,x+12,y+12,light_blue); --lado direito.
draw_line(x-12,y+12,x,y+12,light_blue);
draw_line(x,y+12,x,y+5,light_blue);
draw_line(x,y+5,x+7,y+5,light_blue);
draw_line(x+7,y+5,x+7,y+12,light_blue);
draw_line(x+7,y+12,x+12,y+12,light_blue);
flood_fill(x,y,white);
end torre_branco;

procedure cavalo_preto(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,yellow); --Base.
draw_line(x+12,y-23,x+3,y+22,yellow);
draw_line(x+3,y+22,x,y+15,yellow);
draw_line(x,y+15,x-3,y+22,yellow);
draw_line(x-3,y+22,x-5,y+15,yellow);
draw_line(x-5,y+15,x-14,y+8,yellow);
draw_line(x-14,y+8,x-10,y+4,yellow);
draw_line(x-10,y+4,x-5,y+5,yellow);
draw_line(x-5,y+5,x-12,y-23,yellow);
flood_fill(x,y);
end cavalo_preto;

procedure cavalo_branco(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,light_blue); --Base.
draw_line(x+12,y-23,x+3,y+22,light_blue);
draw_line(x+3,y+22,x,y+15,light_blue);
draw_line(x,y+15,x-3,y+22,light_blue);
draw_line(x-3,y+22,x-5,y+15,light_blue);
draw_line(x-5,y+15,x-14,y+8,light_blue);
draw_line(x-14,y+8,x-10,y+4,light_blue);
draw_line(x-10,y+4,x-5,y+5,light_blue);
draw_line(x-5,y+5,x-12,y-23,light_blue);
flood_fill(x,y,white);
end cavalo_branco;

procedure rei_preto(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,yellow); --Base do Rei.
draw_line(x-12,y-23,x-20,y-4,yellow);  --lado esquerdo da coroa.
draw_line(x+12,y-23,x+20,y-4,yellow);  --lado direito da coroa.
draw_circle(x+12,y+1,10,yellow);       --circulos laterais.
draw_circle(x-12,y+1,10,yellow);
draw_box(x-2,y+6,x+2,y+13,yellow);     --Essas 3 caixas sao a cruz.
draw_box(x-8,y+13,x+8,y+16,yellow);
draw_box(x-2,y+16,x+2,y+21,yellow);

flood_fill(x,y);                     --pintando regiao central.
flood_fill(x+12,y+1);                --pintando circulos laterais.
flood_fill(x-12,y+1);
flood_fill(x,y+8);                   --pintando a cruz.
flood_fill(x,y+14);
flood_fill(x,y+17);

end rei_preto;


procedure rei_branco(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,light_blue); --Base do Rei.
draw_line(x-12,y-23,x-20,y-4,light_blue);  --lado esquerdo da coroa.
draw_line(x+12,y-23,x+20,y-4,light_blue);  --lado direito da coroa.
draw_circle(x+12,y+1,10,light_blue);       --circulos laterais.
draw_circle(x-12,y+1,10,light_blue);
draw_box(x-2,y+6,x+2,y+13,light_blue);     --Essas 3 caixas sao a cruz.
draw_box(x-8,y+13,x+8,y+16,light_blue);
draw_box(x-2,y+16,x+2,y+21,light_blue);

flood_fill(x,y,white);                     --pintando regiao central.
flood_fill(x+12,y+1,white);                --pintando circulos laterais.
flood_fill(x-12,y+1,white);
flood_fill(x,y+8,white);                   --pintando a cruz.
flood_fill(x,y+14,white);
flood_fill(x,y+17,white);

end rei_branco;



-----------------------Aqui sao procedimentos que deixam a peca vermelha quando selecionada---------------

procedure peao_selecionado(x,y:integer) is
begin
draw_circle(x,y+3,8,light_red);
draw_box(x-11,y-24,x+11,y-15,light_red);
draw_line(x-4,y-5,x-4,y-15,light_red);
draw_line(x+4,y-5,x+4,y-15,light_red);
end peao_selecionado;

procedure bispo_selecionado(x,y:integer) is
begin
draw_box(x-12,y-23,x+12,y-20,light_red); --Base.
draw_line(x,y-20,x-15,y,light_red);
draw_line(x-15,y,x,y+20,light_red);
draw_line(x,y-20,x+15,y,light_red);
draw_line(x+15,y,x+8,y+10,light_red);
draw_line(x+8,y+10,x+2,y+2,light_red);
draw_line(x+2,y+2,x-1,y+6,light_red);
draw_line(x-1,y+6,x+4,y+14,light_red);
draw_line(x+4,y+14,x,y+20,light_red);
end bispo_selecionado;

procedure dama_selecionado(x,y:integer) is
--Esse procedimento contorna uma dama numa casa cujo centro e' x,y
begin

draw_line(x-12,y-23,x+12,y-23,light_red); --Base da dama.
draw_line(x-12,y-23,x-23,y+12,light_red); --lado esquerdo da coroa.
draw_line(x+12,y-23,x+23,y+12,light_red); --lado direito da coroa.
draw_line(x-23,y+12,x-11,y-5,light_red);
draw_line(x+23,y+12,x+11,y-5,light_red);
draw_line(x+11,y-5,x+6,y+12,light_red);
draw_line(x-11,y-5,x-6,y+12,light_red);
draw_line(x+6,y+12,x,y-5,light_red);
draw_line(x-6,y+12,x,y-5,light_red);
end dama_selecionado;

procedure torre_selecionado(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,light_red); --Base da torre.
draw_line(x-12,y-23,x-12,y+12,light_red); --lado esquerdo.
draw_line(x+12,y-23,x+12,y+12,light_red); --lado direito.
draw_line(x-12,y+12,x,y+12,light_red);
draw_line(x,y+12,x,y+5,light_red);
draw_line(x,y+5,x+7,y+5,light_red);
draw_line(x+7,y+5,x+7,y+12,light_red);
draw_line(x+7,y+12,x+12,y+12,light_red);
end torre_selecionado;

procedure cavalo_selecionado(x,y:integer) is
begin
draw_line(x-12,y-23,x+12,y-23,light_red); --Base.
draw_line(x+12,y-23,x+3,y+22,light_red);
draw_line(x+3,y+22,x,y+15,light_red);
draw_line(x,y+15,x-3,y+22,light_red);
draw_line(x-3,y+22,x-5,y+15,light_red);
draw_line(x-5,y+15,x-14,y+8,light_red);
draw_line(x-14,y+8,x-10,y+4,light_red);
draw_line(x-10,y+4,x-5,y+5,light_red);
draw_line(x-5,y+5,x-12,y-23,light_red);
end cavalo_selecionado;

procedure rei_selecionado(x,y:integer) is
begin

draw_line(x-12,y-23,x+12,y-23,light_red); --Base do Rei.
draw_line(x-12,y-23,x-20,y-4,light_red);  --lado esquerdo da coroa.
draw_line(x+12,y-23,x+20,y-4,light_red);  --lado direito da coroa.
draw_circle(x+12,y+1,10,light_red);       --circulos laterais.
draw_circle(x-12,y+1,10,light_red);
draw_box(x-2,y+6,x+2,y+13,light_red);     --Essas 3 caixas sao a cruz.
draw_box(x-8,y+13,x+8,y+16,light_red);
draw_box(x-2,y+16,x+2,y+21,light_red);

end rei_selecionado;

procedure seleciona(x,y:integer) is
begin
 if board((x+25)/50,(y+25)/50)=1  or board((x+25)/50,(y+25)/50)=-1   then peao_selecionado(x,y);    end if;
 if board((x+25)/50,(y+25)/50)=3  or board((x+25)/50,(y+25)/50)=-3   then bispo_selecionado(x,y);   end if;
 if board((x+25)/50,(y+25)/50)=4  or board((x+25)/50,(y+25)/50)=-4   then cavalo_selecionado(x,y);  end if;
 if board((x+25)/50,(y+25)/50)=7  or board((x+25)/50,(y+25)/50)=-7   then torre_selecionado(x,y);   end if;
 if board((x+25)/50,(y+25)/50)=20 or board((x+25)/50,(y+25)/50)=-20  then dama_selecionado(x,y);    end if;
 if board((x+25)/50,(y+25)/50)=999 or board((x+25)/50,(y+25)/50)=-999  then rei_selecionado(x,y);     end if;
end seleciona;

procedure deseleciona(x,y:integer) is
begin
if board((x+25)/50,(y+25)/50)=1   then peao_branco(x,y);    end if;
if board((x+25)/50,(y+25)/50)=-1  then peao_preto(x,y);     end if;
if board((x+25)/50,(y+25)/50)=3   then bispo_branco(x,y);   end if;
if board((x+25)/50,(y+25)/50)=-3  then bispo_preto(x,y);    end if;
if board((x+25)/50,(y+25)/50)=4   then cavalo_branco(x,y);  end if;
if board((x+25)/50,(y+25)/50)=-4  then cavalo_preto(x,y);   end if;
if board((x+25)/50,(y+25)/50)=7   then torre_branco(x,y);   end if;
if board((x+25)/50,(y+25)/50)=-7  then torre_preto(x,y);    end if;
if board((x+25)/50,(y+25)/50)=20  then dama_branco(x,y);    end if;
if board((x+25)/50,(y+25)/50)=-20 then dama_preto(x,y);     end if;
if board((x+25)/50,(y+25)/50)=999  then rei_branco(x,y);     end if;
if board((x+25)/50,(y+25)/50)=-999 then rei_preto(x,y);      end if;
end deseleciona;


-----------------------Fim dos procedimentos para deixar casa vermelha.-----------------------------

--------------------Aqui eu ponho as pecas----------------------------------------------------------

procedure poem_pecas is
begin
--aqui vou por as pecas nesse array.
for a in 1..8 loop
  for b in 1..8 loop
    board(a,b):=0;
  end loop;
end loop;

for a in 1..8 loop
  board(a,2):=1; --Peoes brancos.
  board(a,7):=-1;	  
end loop;

--torres.
board(1,1):=7;
board(8,1):=7;
board(1,8):=-7;
board(8,8):=-7;
--cavalos.
board(2,1):=4;
board(7,1):=4;
board(2,8):=-4;
board(7,8):=-4;
--bispos.
board(3,1):=3;
board(6,1):=3;
board(3,8):=-3;
board(6,8):=-3;
--Rei e Dama.
board(4,1):=20;
board(4,8):=-20;
board(5,1):=999;
board(5,8):=-999;

end poem_pecas;

----------------------------procedimento desenha pecas-----------------------------------------------------------

procedure desenha_pecas is
begin
for a in 1..8 loop
    for b in 1..8 loop
       if board(a,b)=1    then peao_branco(a*50-25,b*50-25);   end if;
       if board(a,b)=-1   then peao_preto(a*50-25,b*50-25);    end if;
       if board(a,b)=3    then bispo_branco(a*50-25,b*50-25);  end if;
       if board(a,b)=-3   then bispo_preto(a*50-25,b*50-25);   end if;
       if board(a,b)=4    then cavalo_branco(a*50-25,b*50-25); end if;
       if board(a,b)=-4   then cavalo_preto(a*50-25,b*50-25);  end if;
       if board(a,b)=7    then torre_branco(a*50-25,b*50-25);  end if;
       if board(a,b)=-7   then torre_preto(a*50-25,b*50-25);   end if;
       if board(a,b)=20   then dama_branco(a*50-25,b*50-25);   end if;
       if board(a,b)=-20  then dama_preto(a*50-25,b*50-25);    end if;
       if board(a,b)=999  then rei_branco(a*50-25,b*50-25);    end if;
       if board(a,b)=-999 then rei_preto(a*50-25,b*50-25);     end if;  
    end loop;
end loop;
end desenha_pecas;


----------------------------procedimento desenha tabuleiro-------------------------------------------------------

procedure desenha_tabuleiro is
begin

Set_Window_Title(Title => "PreChess. Author: Jos� Lauro Strapasson - Brazil. (Written in Ada95)");

draw_line(0,400,400,400);

display_text(0,401,"New");
display_text(100,401,"New(black)");
display_text(200,401,"Reverse");
display_text(300,401,"Exit");


draw_line(0,50,400,50);
draw_line(0,100,400,100);
draw_line(0,150,400,150);
draw_line(0,200,400,200);
draw_line(0,250,400,250);
draw_line(0,300,400,300);
draw_line(0,350,400,350);

draw_line(50,0,50,400);
draw_line(100,0,100,400);
draw_line(150,0,150,400);
draw_line(200,0,200,400);
draw_line(250,0,250,400);
draw_line(300,0,300,400);
draw_line(350,0,350,400);

for a in 1..4 loop
flood_fill(25,25+100*(a-1),light_gray);
flood_fill(125,25+100*(a-1),light_gray);
flood_fill(225,25+100*(a-1),light_gray);
flood_fill(325,25+100*(a-1),light_gray);
end loop;


for a in 1..4 loop

flood_fill(75,75+100*(a-1),light_gray);
flood_fill(175,75+100*(a-1),light_gray);
flood_fill(275,75+100*(a-1),light_gray);
flood_fill(375,75+100*(a-1),light_gray);
end loop;

end desenha_tabuleiro;

----------------------------Esse procedimento vira o tabuleiro-----------------------------------------------------

procedure vire is
board_copia:array(1..8,1..8) of integer;
begin
if virado=true then virado:=false; else virado:=true; end if;
--Isso faz uma copia e apaga os desenhos das pecas.
for a in 1..8 loop
    for b in 1..8 loop
    board_copia(a,b):=board(a,b);
    if board(a,b)/=0 then
	    limpa_casa(a*50-25,b*50-25);
    end if;	    
    end loop;
end loop;
--Isso efetivamente vira.
for a in 1..8 loop
    for b in 1..8 loop
    board(a,b):=board_copia(9-a,9-b);   --1 vira 8 e 8 vira 1!
    end loop;
end loop;

desenha_pecas;

end vire;


procedure escolhe_promovido(x,y:integer) is
  escolhido,mx1,my1:integer;
begin
--X e a coluna, devendo ser numero entre 1 e 8.
--Y e a linha devendo ser 1 para para peao branco(tabuleiro nao virado)
--e 8 para peao preto(tabuleiro nao virado) ou o contrario se virado.
limpa_casa(x*50-25,y*50-25);--Centro da casa.
draw_box(x*50-50,y*50-50,x*50,y*50,white,true);
draw_box(x*50-50,y*50-50,x*50,y*50,green);

draw_line(x*50-50,y*50-25,x*50,y*50-25);
draw_line(x*50-25,y*50-50,x*50-25,y*50);

display_text(x*50-42,y*50-20,"Q");
display_text(x*50-17,y*50-20,"R");
display_text(x*50-42,y*50-45,"N");
display_text(x*50-17,y*50-45,"B");

loop
 get_mouse_button(Left_Button,MX1,MY1);
exit when mx1>x*50-50 and mx1<x*50 and my1>y*50-50 and my1<y*50;
end loop;

if mx1<x*50-25 then
   if my1<y*50-25 then
     escolhido:=4; --CAVALO!
     promovido_da_pessoa:='n';
   else
     escolhido:=20; --DAMA!
     promovido_da_pessoa:='q';
   end if;	   
else
   if my1<y*50-25 then
     escolhido:=3; --BISPO!
     promovido_da_pessoa:='b';
   else
     escolhido:=7; --TORRE!
     promovido_da_pessoa:='r';
   end if;
end if;

limpa_casa(x*50-25,y*50-25);

if board(x,y)>0 then       --A nova peca tem de ser da mesma cor do peao!
 board(x,y):=escolhido;
else
 board(x,y):=-escolhido;
end if;

	
if board(x,y)=20  then dama_branco(x*50-25,y*50-25);   end if;
if board(x,y)=-20 then dama_preto(x*50-25,y*50-25);    end if;
if board(x,y)=7   then torre_branco(x*50-25,y*50-25);  end if;
if board(x,y)=-7  then torre_preto(x*50-25,y*50-25);   end if;
if board(x,y)=4   then cavalo_branco(x*50-25,y*50-25); end if;
if board(x,y)=-4  then cavalo_preto(x*50-25,y*50-25);  end if;
if board(x,y)=3   then bispo_branco(x*50-25,y*50-25);  end if;
if board(x,y)=-3  then bispo_preto(x*50-25,y*50-25);   end if;

end escolhe_promovido;


procedure nova is
begin
 for a in 1..8 loop
    for b in 1..8 loop
	 if board(a,b)/=0 then 
	      limpa_casa(a*50-25,b*50-25);
	 end if;
    end loop;
 end loop;
 
 rei_humano_mexido:=false;
 torre_humana_A_mexida:=false;
 torre_humana_h_mexida:=false;
 RoqueHfeito:=False;
 numero_de_meu_movimento:=0;
 poem_pecas;
 desenha_pecas;
 pessoa_com_branca:=true;
 virado:=false;
end nova;

                   
procedure fazpassant(x1,y1,x2,y2:integer) is
begin
--Esse procedimento apaga o peao comido.
--no "En passant".
board(x2,y1):=0;
limpa_casa(x2*50-25,y1*50-25);
end fazpassant;


procedure fazroque(a,b:integer) is
begin
--Esse procedimento recebe a e b onde a e b s�o as coordenadas para onde o rei FOI movido.
--Dai ele simplesmente pega a torre e poem do outro lado desenhando ela tamb�m!
--Se o tabuleiro n�o estiver envertido um Rei n�o mexido fica na coluna E. Isto � na 5.
--O roque longo corresponde a a=7 e o curto a a=3, enquanto b vale 1 ou 8.
--Se o tabuleiro estiver envertido ent�o o Rei fica na coluna 4, o grande roque � dado por a=6 e o pequeno
--por a=2.
	
 if a=7 and virado=false then
     board(6,b):=board(8,b);
     board(8,b):=0;
     limpa_casa(8*50-25,b*50-25);
     if board(6,b)=7 then
	torre_branco(6*50-25,b*50-25);
     else
	torre_preto(6*50-25,b*50-25);
     end if;
 end if;
 if a=3 and virado=false then
     board(4,b):=board(1,b);
     board(1,b):=0;
     limpa_casa(1*50-25,b*50-25);
     if board(4,b)=7 then
	torre_branco(4*50-25,b*50-25);
     else
	torre_preto(4*50-25,b*50-25);
     end if;
 end if;
 if a=6 and virado=true then
     board(5,b):=board(8,b);
     board(8,b):=0;
     limpa_casa(8*50-25,b*50-25);
     if board(5,b)=7 then
	torre_branco(5*50-25,b*50-25);
     else
	torre_preto(5*50-25,b*50-25);
     end if;
 end if;
 if a=2 and virado=true then
     board(3,b):=board(1,b);
     board(1,b):=0;
     limpa_casa(1*50-25,b*50-25);
     if board(3,b)=7 then
	torre_branco(3*50-25,b*50-25);
     else
	torre_preto(3*50-25,b*50-25);
     end if;
 end if;
end fazroque;

procedure exposto_a_xeque is
    rei_i, rei_j, temp:integer;
begin

--Ele vai verificar se a pessoa se exp�em a xeque.
	
expoem_rei:=false; --expoem_rei � variavel global!


if abs(board((mousex1+25)/50,(mousey1+25)/50))=999 and abs((mousex1+25)/50 - (mousex2+25)/50)=2 then
 --Isso foi um roque!!!!!
 --No caso do Roque existe 3 casas que n�o podem estar amea�adas.
 --Aquela em que o rei estava.
 --Aquela para onde o rei foi.
 --E a intermediaria.

 for a in 1..8 loop
     for b in 1..8 loop
	 if pessoa_com_branca=true and board(a,b)<0 then
            if validade(a,b,(mousex2+25)/50,(mousey2+25)/50)=true or validade(a,b,(mousex1+25)/50,(mousey1+25)/50)=true 
		    or validade(a,b,(mousex2+mousex1+50)/100,(mousey2+25)/50)=true then
	        expoem_rei:=true; --Esse ultimo � a posicao intermediaria.
	    end if;
	 end if;
	 if pessoa_com_branca=false and board(a,b)>0 then
	    if validade(a,b,(mousex2+25)/50,(mousey2+25)/50)=true or validade(a,b,(mousex1+25)/50,(mousey1+25)/50)=true
		    or validade(a,b,(mousex2+mousex1+50)/100,(mousey2+25)/50)=true then
	        expoem_rei:=true; --Esse ultimo � a posicao intermediaria.
	    end if;
	 end if;
     end loop;
 end loop;

else
--Bom, ent�o n�o foi um roque!
 temp:=board((mousex2+25)/50,(mousey2+25)/50);
 board((mousex2+25)/50,(mousey2+25)/50):=board((mousex1+25)/50,(mousey1+25)/50); --Joga temporariamente.
 board((mousex1+25)/50,(mousey1+25)/50):=0;
--Por que mover temporariamente?? � que o rei pode estar se exponda a xeque justamente ao comer um pe�a da engine.
--Como a validade nunca vai permitir que algu�m como sua propria peca � preciso efetuar a jogada primeiro.

--Bom, primeiro temos que achar o Rei da pessoa!
for a in 1..8 loop
   for b in 1..8 loop
	 if board(a,b)=999 and pessoa_com_branca=true then
		 rei_i:=a; rei_j:=b;
	 end if;
	 if board(a,b)=-999 and pessoa_com_branca=false then
		 rei_i:=a; rei_j:=b;
	 end if;
   end loop;
end loop;

for a in 1..8 loop
    for b in 1..8 loop
        if validade(a,b,rei_i,rei_j)=true then
		expoem_rei:=true; 
	end if;
    end loop;
end loop;

board((mousex1+25)/50,(mousey1+25)/50):=board((mousex2+25)/50,(mousey2+25)/50); --Desjoga.
board((mousex2+25)/50,(mousey2+25)/50):=temp;

end if;

end exposto_a_xeque;


procedure daengine is
 sairdaengine:boolean:=false;
 x1,x2,y1,y2:integer;
 sinal:integer;
begin
--Esse procimento recebe coisas da engine e efetua as jogadas.-----------
--E' baseado no "tradutor" usado no Prechess-----------------------------
 
 x1:=ultimo_lance_da_engine(1);
 y1:=ultimo_lance_da_engine(2);
 x2:=ultimo_lance_da_engine(3);
 y2:=ultimo_lance_da_engine(4);

if sairdaengine=false then

 if board(x2,y2)=0 and abs(board(x1,y1))=1 and x2/=x1 then
	 fazpassant(x1,y1,x2,y2);
 end if;

 board(x2,y2):=board(x1,y1);
 board(x1,y1):=0;

 apaga_contorno_vermelho(casa_inicial_x,casa_inicial_y);
 apaga_contorno_vermelho(casa_final_x,casa_final_y);

 casa_final_x:=x2*50-25;
 casa_final_y:=y2*50-25;

 casa_inicial_x:=x1*50-25;
 casa_inicial_y:=y1*50-25;

 if (y2=8 or y2=1) and abs(board(x2,y2))=1 then
   sinal:=abs(board(x2,y2))/board(x2,y2);
   board(x2,y2):=20*sinal;
 end if;

 limpa_casa(x1*50-25,y1*50-25);

 limpa_casa(x2*50-25,y2*50-25);

 contorno_vermelho(x2*50-25,y2*50-25);
 contorno_vermelho(x1*50-25,y1*50-25);

end if;


 ----------Desenha a peca jogada pela engine--------------------------------------------------------
 
 if board(x2,y2)=1  then peao_branco(x2*50-25,y2*50-25); end if;
 if board(x2,y2)=-1 then peao_preto(x2*50-25,y2*50-25);  end if;

 if board(x2,y2)=3  then bispo_branco(x2*50-25,y2*50-25); end if;
 if board(x2,y2)=-3 then bispo_preto(x2*50-25,y2*50-25);  end if;

 if board(x2,y2)=4  then cavalo_branco(x2*50-25,y2*50-25); end if;
 if board(x2,y2)=-4 then cavalo_preto(x2*50-25,y2*50-25);  end if;

 if board(x2,y2)=7  then torre_branco(x2*50-25,y2*50-25); end if;
 if board(x2,y2)=-7 then torre_preto(x2*50-25,y2*50-25);  end if;

 if board(x2,y2)=20  then dama_branco(x2*50-25,y2*50-25); end if;
 if board(x2,y2)=-20 then dama_preto(x2*50-25,y2*50-25);  end if;
	
 if board(x2,y2)=999  then rei_branco(x2*50-25,y2*50-25); end if;
 if board(x2,y2)=-999 then rei_preto(x2*50-25,y2*50-25);  end if;


 if abs(board(x2,y2))=999 and y2=y1 and abs(x2-x1)=2 then
   fazroque(x2,y2);
 end if;


--exit when sairdaengine=true;
--end loop;

end daengine;


procedure desenha_ampulieta is
begin
draw_line(380,402,390,412);
draw_line(380,412,390,402);
draw_line(380,412,390,412);
draw_line(380,402,390,402);
end desenha_ampulieta;

procedure apaga_ampulieta is
begin
draw_box(380,402,390,412,white,true);
end apaga_ampulieta;


 function Roque_Hpermitido(A,B: in Integer) return Boolean is
   Resultado: Boolean; --vai dizer se a pessoa pode fazer roque ou n�o.
 begin

    Resultado:=False; --Em principio n�o pois qualquer coisa pode chamar essa funcao.

    if (A=60 and B=58) or (A=60 and B=62) or (A=61 and B=63) or (A=61 and B=59) then
       Resultado:=True; --Se isso acontecer em principio pode.
    end if;
    if RoqueHfeito=True then Resultado:=False; end if;
    --caso o roque j� tenha sido feito n�o pode mais.

   if A=60 and B=58 then
      if Tabuleiro(60) /= -999 or Tabuleiro(57) /= -7 or Tabuleiro(58) /= 0 or Tabuleiro(59) /= 0 or
      Rei60movido=True or Torre57movida=True
      then
         Resultado:=False;
      end if;

      for C in 1..64 loop
         if Tabuleiro(C)>0 and (Validade(C,60)=True or Validade(C,58)=True or Validade(C,59)=True) then
            Resultado:=False; --Veja que 57 n�o vai pois a torre pode estar amea�ada.
         end if;
      end loop;

   end if;

   if A=60 and B=62 then
      if Tabuleiro(60) /= -999 or Tabuleiro(64) /= -7 or Tabuleiro(61) /= 0 or Tabuleiro(62) /= 0 or
      Tabuleiro(63) /= 0 or Rei60movido=True or Torre64movida=True
      then --Veja que esse � um grande roque.
         Resultado:=False;
      end if;

      for C in 1..64 loop
         if Tabuleiro(C)>0 and (Validade(C,60)=True or Validade(C,61)=True or Validade(C,62)=True or
         Validade(C,63)=True) then
            Resultado:=False;
         end if;
      end loop;
   end if;

   if A=61 and B=63 then
       if Tabuleiro(61) /= -999 or Tabuleiro(64) /= -7 or Tabuleiro(62) /= 0 or Tabuleiro(63) /= 0
       or  Rei61movido=True or Torre64movida=True
       then
         Resultado:=False;
      end if;

      for C in 1..64 loop
         if Tabuleiro(C)>0 and (Validade(C,61)=True or Validade(C,62)=True or Validade(C,63)=True) then
            Resultado:=False;
         end if;
      end loop;
   end if;

   if A=61 and B=59 then
      if Tabuleiro(61) /= -999 or Tabuleiro(57) /= -7 or Tabuleiro(58) /= 0 or Tabuleiro(59) /= 0 or
      Tabuleiro(60) /= 0 or Rei61movido=True or Torre57movida=True
      then --Veja que esse � um grande roque.
         Resultado:=False;
      end if;

      for C in 1..64 loop
         if Tabuleiro(C)>0 and (Validade(C,61)=True or Validade(C,60)=True or Validade(C,59)=True or
         Validade(C,58)=True) then
            Resultado:=False;
         end if;
      end loop;
   end if;

   return Resultado;

 end Roque_Hpermitido;


  procedure MateNele is
 --E' um porcedimento e nao uma funcao pois ele recebe
 --como dado de entrada somente a posicao do tabuleiro.
   Temp1, Temp2: Integer;
   Morre: array(1..64,1..64) of Boolean;
   Exequemate_TNele:Boolean;
  procedure S_Lance(Ii,Jj:Integer)  is --Procedimento dentro do MateNele.
  begin
   for kk in 1..64 loop
       if tabuleiro(kk) > 0 then   --Ou seja, se tem uma pe�a da pessoa.
          for ll in 1..64 loop
             if tabuleiro(ll) = -999 then --o uso do and deixaria mais lento!
               if validade(kk,ll)=true then
                  Morre(II,JJ):=True;
                  --O computador "comeu" o Rei do advers�rio!!!
               end if;
             end if;
          end loop;
       end if;
   end loop;
  end S_Lance;

 begin --Incio do Mate nele.

 Exequemate_TNele:=true;

 for ii in 1..64 loop
      if tabuleiro(ii) < 0 then   --Ou seja, se tem uma peca da pessoa.
          temp1:=tabuleiro(ii);--So para lembrar que peca era.

          for jj in 1..64 loop
            if tabuleiro(jj) >= 0 then --o uso do and deixaria mais lento!
             if validade(ii,jj)=true then

             Morre(Ii,Jj):=False;

             tabuleiro(ii) := 0;      --A pe�a sai, ele comeca a jogar em seu pensamento!
             temp2:=tabuleiro(jj);
             tabuleiro(jj):=temp1; --pronto, jogou!
             --A pessoa fez uma jogada qualquer possivel.
             S_Lance(iI,Jj);  --Executa o procedimento S_Lance, que e parecido.

             if Morre(iI,Jj)=false then  --Basta 1 para nao ser chequemate!
                Exequemate_TNele:=false;
             end if;

             tabuleiro(jj):=temp2;
             tabuleiro(ii):=temp1;--Tudo volta ao normal! Lembre-se, ele esta pensando e nao jogando!

             end if;
            end if;
          end loop;
       end if;
  end loop;

 if Exequemate_TNele=True then ExequemateNele:=True;  end if;
 end MateNele;

 function Expoemreidele(A,B: in Integer) return Boolean is
   Temporario:Integer;
   resultado:boolean;
 begin
 Resultado:=False;
 Temporario:=Tabuleiro(B);
 Tabuleiro(B):=Tabuleiro(A);
 Tabuleiro(A):=0;
 for bb in 1..64 loop
    if Tabuleiro(bB)=-999 then
      for aa in 1..64 loop
         if Tabuleiro(Aa)>=0 then --O uso do and tornaria mais lento!
            if Validade(aA,Bb)=True then
            Resultado:=True;
            end if;
         end if;
      end loop;
    end if;
 end loop;
 Tabuleiro(A):=Tabuleiro(B);
 Tabuleiro(B):=Temporario;
 return Resultado;
 end Expoemreidele;


procedure desenha_peca_jogada is
begin
 ----------Desenha a peca jogada--------------------------------------------------------
 if board((mousex2+25)/50,(mousey2+25)/50)=1  then peao_branco(mousex2,mousey2); end if;
 if board((mousex2+25)/50,(mousey2+25)/50)=-1 then peao_preto(mousex2,mousey2);  end if;

 if board((mousex2+25)/50,(mousey2+25)/50)=3  then bispo_branco(mousex2,mousey2); end if;
 if board((mousex2+25)/50,(mousey2+25)/50)=-3 then bispo_preto(mousex2,mousey2);  end if;

 if board((mousex2+25)/50,(mousey2+25)/50)=4  then cavalo_branco(mousex2,mousey2); end if;
 if board((mousex2+25)/50,(mousey2+25)/50)=-4 then cavalo_preto(mousex2,mousey2);  end if;

 if board((mousex2+25)/50,(mousey2+25)/50)=7  then torre_branco(mousex2,mousey2); end if;
 if board((mousex2+25)/50,(mousey2+25)/50)=-7 then torre_preto(mousex2,mousey2);  end if;

 if board((mousex2+25)/50,(mousey2+25)/50)=20  then dama_branco(mousex2,mousey2); end if;
 if board((mousex2+25)/50,(mousey2+25)/50)=-20 then dama_preto(mousex2,mousey2);  end if;
	
 if board((mousex2+25)/50,(mousey2+25)/50)=999  then rei_branco(mousex2,mousey2); end if;
 if board((mousex2+25)/50,(mousey2+25)/50)=-999 then rei_preto(mousex2,mousey2);  end if;

if abs(board((mousex2+25)/50,(mousey2+25)/50))=999 and abs((mousex2+25)/50 - (mousex1+25)/50)=2 then
   fazroque((mousex2+25)/50,(mousey2+25)/50);
end if;

if abs(board((mousex2+25)/50,(mousey2+25)/50))=999 then
 rei_humano_mexido:=true; 
end if;


if pessoa_com_branca=true then
 if virado=false then
   if (mousex1+25)/50=1 and (mousey1+25)/50=1 then
       torre_humana_A_mexida:=true;
   end if;
   if (mousex1+25)/50=8 and (mousey1+25)/50=1 then
       torre_humana_h_mexida:=true;
   end if;
 else
   if (mousex1+25)/50=1 and (mousey1+25)/50=8 then
       torre_humana_h_mexida:=true;
   end if;
   if (mousex1+25)/50=8 and (mousey1+25)/50=8 then
       torre_humana_a_mexida:=true;
   end if;
 end if;
else
 if virado=false then
   if (mousex1+25)/50=1 and (mousey1+25)/50=8 then
       torre_humana_A_mexida:=true;
   end if;
   if (mousex1+25)/50=8 and (mousey1+25)/50=8 then
       torre_humana_h_mexida:=true;
   end if;
 else
   if (mousex1+25)/50=1 and (mousey1+25)/50=1 then
       torre_humana_h_mexida:=true;
   end if;
   if (mousex1+25)/50=8 and (mousey1+25)/50=1 then
       torre_humana_a_mexida:=true;
   end if;
 end if;

end if;

end desenha_peca_jogada;





begin    --Inicio da interface do usuario, procedimento prechess.

 --relacionado a pequena abertura implementada.
 numero_de_meu_movimento:=0;
 Open_Graph_Window(400,415);
 desenha_tabuleiro; --desenha o tabuleiro!
 poem_pecas;
 desenha_pecas;

--Aqui parei de copiar coisas do PreBoard!!!!!!

 Apresentacao;
 

loop   --Aqui executa infinitamente aquele meu programa grande. A saida dele sera cc e dd.
--Loop A.
	

jogou:=false;

loop ---------------------Loop da jogada! So sai apos a pessoa jogar!----------------------------------------------------
	
 get_mouse_button(Left_Button,MouseX1,MouseY1);
 
 --O comando acima pega a posicao do mouse ao ser clicado. So' tem na versao 2000 da Adagraph.---------------------------
 --De certo modo com as outras versoes seria impossivel fazer esse programa.---------------------------------------------

 if    mouseX1<=50 then  mouseX1:=25;
 elsif mouseX1<=100 then mouseX1:=75;
 elsif mouseX1<=150 then mouseX1:=125;
 elsif mouseX1<=200 then mouseX1:=175;
 elsif mouseX1<=250 then mouseX1:=225;
 elsif mouseX1<=300 then mouseX1:=275;
 elsif mouseX1<=350 then mouseX1:=325;
 else                    mouseX1:=375;
 end if;

 if    mousey1<=50  then mousey1:=25;
 elsif mousey1<=100 then mousey1:=75;
 elsif mousey1<=150 then mousey1:=125;
 elsif mousey1<=200 then mousey1:=175;
 elsif mousey1<=250 then mousey1:=225;
 elsif mousey1<=300 then mousey1:=275;
 elsif mousey1<=350 then mousey1:=325;
 elsif mousey1<=400 then mousey1:=375;
 else  menu:=true;	
 end if;
 
 if menu=false then
   seleciona(mousex1,mousey1);
 end if;
 
if menu=false then	
 get_mouse_button(Left_Button,MouseX2,MouseY2);
 deseleciona(mousex1,mousey1);
end if;
--Nao vou verificar se existe peca na casa!
--X1,Y1 e X2 e Y2 vao ser qualquer coordenada de 0..400 e 0..400.
--Esse parte do programa transforma eles em coordenadas de centro de casa.
	--Veja que se usa-se-mos um case deveria por mousex1>50 and mousex1<=100.
--O carater esculisivo do elsif torna isso desnecessario.


if    mouseX2<=50 then  mouseX2:=25;
elsif mouseX2<=100 then mouseX2:=75;
elsif mouseX2<=150 then mouseX2:=125;
elsif mouseX2<=200 then mouseX2:=175;
elsif mouseX2<=250 then mouseX2:=225;
elsif mouseX2<=300 then mouseX2:=275;
elsif mouseX2<=350 then mouseX2:=325;
else                    mouseX2:=375;
end if;

if    mousey2<=50 then  mousey2:=25;
elsif mousey2<=100 then mousey2:=75;
elsif mousey2<=150 then mousey2:=125;
elsif mousey2<=200 then mousey2:=175;
elsif mousey2<=250 then mousey2:=225;
elsif mousey2<=300 then mousey2:=275;
elsif mousey2<=350 then mousey2:=325;
elsif mousey2<=400 then mousey2:=375;
else menu:=true;
end if;

if menu=true then
   if    mousex1 <=100  then  nova; menu:=false;
   elsif mousex1 <=200  then  nova; pessoa_com_branca:=false; jogou:=true; menu:=false;
   elsif mousex1 <=300  then  vire; menu:=false;
   elsif mousex1 <=400  then  sair:=true; 
   end if;
end if;

--Isso e parte que joga:
if menu=false then

if validade((mousex1+25)/50,(mousey1+25)/50,(mousex2+25)/50,(mousey2+25)/50)=true and 
   abs(board((mousex2+25)/50,(mousey2+25)/50)) /=999 and 
   (board((mousex1+25)/50,(mousey1+25)/50)>0 xor pessoa_com_branca=false)then

   lance_da_pessoa(1):=(mousex1+25)/50;
   lance_da_pessoa(2):=(mousey1+25)/50;
   lance_da_pessoa(3):=(mousex2+25)/50;
   lance_da_pessoa(4):=(mousey2+25)/50;

 exposto_a_xeque;

 if expoem_rei=false then

 limpa_casa(mousex1,mousey1); --Limpa as casas.
 limpa_casa(mousex2,mousey2);

 if board((mousex2+25)/50,(mousey2+25)/50)=0 and abs(board((mousex1+25)/50,(mousey1+25)/50))=1 and mousex2/=mousex1 then
	 fazpassant((mousex1+25)/50,(mousey1+25)/50,(mousex2+25)/50,(mousey2+25)/50);
 end if;

 board((mousex2+25)/50,(mousey2+25)/50):=board((mousex1+25)/50,(mousey1+25)/50); --Joga.
 board((mousex1+25)/50,(mousey1+25)/50):=0;

 apaga_contorno_vermelho(casa_inicial_x,casa_inicial_y);
 apaga_contorno_vermelho(casa_final_x,casa_final_y);

 contorno_vermelho(mousex2,mousey2);
 contorno_vermelho(mousex1,mousey1);

 casa_final_x:=mousex2;
 casa_final_y:=mousey2;

 casa_inicial_x:=mousex1;
 casa_inicial_y:=mousey1;

 --------------------------------Isso tem de haver com a promocao.-------------------------------------	 
 for a in 1.. 8 loop
  if board(a,8)=1  and virado=false and pessoa_com_branca=true  then escolhe_promovido(a,8); end if;
  if board(a,1)=1  and virado=true  and pessoa_com_branca=true  then escolhe_promovido(a,1); end if;
  if board(a,1)=-1 and virado=false and pessoa_com_branca=false then escolhe_promovido(a,1); end if;
  if board(a,8)=-1 and virado=true  and pessoa_com_branca=false then escolhe_promovido(a,8); end if;
 end loop;


 jogou:=true;

 desenha_peca_jogada;


--Atualizando o array tabuleiro. 
if pessoa_com_branca=true then
  if virado=false then
    for a in 1..8 loop
       for b in 1..8 loop
               	tabuleiro((a-1)*8 + b):=board(b,9-a)*(-1);
       end loop;
    end loop;
  else 
    for a in 1..8 loop
       for b in 1..8 loop
        	tabuleiro((a-1)*8 + b):=board(9-b,a)*(-1);
       end loop;
    end loop;
  end if;
else
  if virado=false then
    for a in 1..8 loop
       for b in 1..8 loop
               	tabuleiro((a-1)*8 + b):=board(9-b,a);
       end loop;
    end loop;
  else 
    for a in 1..8 loop
       for b in 1..8 loop
        	tabuleiro((a-1)*8 + b):=board(b,9-a);
       end loop;
    end loop;
  end if;	

end if;



end if; --Fim do Expoem rei=false.
 
end if; --Fim do IF validade.
end if; --Fim do IF menu=false.



exit when jogou=true or sair=true; ------------Para sair do loop da jogada.----------------------------------------
end loop; -------------------------------------Fim do loop da jogada-----------------------------------------------


exit when sair=true;


desenha_ampulieta;

prechess2;

apaga_ampulieta;

exit when Cc=Dd;

tabuleiro(dd):=tabuleiro(cc);
tabuleiro(cc):=0;

if Tabuleiro(64)=1 then Tabuleiro(64):=20; end if;  --Aqui eu promovo meus proprios peoes.
if Tabuleiro(63)=1 then Tabuleiro(63):=20; end if;  --So falta fazer o programa buscar isso.
if Tabuleiro(62)=1 then Tabuleiro(62):=20; end if;  --Pois a principio ele nao sabe que isso leva
if Tabuleiro(61)=1 then Tabuleiro(61):=20; end if;  --a uma soma maior. Mas e' claro ai passa a ser
if Tabuleiro(60)=1 then Tabuleiro(60):=20; end if;  --um defeito de estrategia e nao mais uma questao
if Tabuleiro(59)=1 then Tabuleiro(59):=20; end if;  --de nao suportar uma jogada do xadrez.
if Tabuleiro(58)=1 then Tabuleiro(58):=20; end if;
if Tabuleiro(57)=1 then Tabuleiro(57):=20; end if;


if pessoa_com_branca=true then	
  if virado=false then

    ultimo_lance_da_engine(1):=9-(65-cc-((64-cc)/8)*8); --Aqui o /8 da a divisao inteira!!!
    ultimo_lance_da_engine(2):=(64-cc)/8+1;
    ultimo_lance_da_engine(3):=9-(65-dd-((64-dd)/8)*8);
    ultimo_lance_da_engine(4):=(64-dd)/8+1;
  else
    ultimo_lance_da_engine(1):=(65-cc-((64-cc)/8)*8); --Aqui o /8 da a divisao inteira!!!
    ultimo_lance_da_engine(2):=9-((64-cc)/8+1);
    ultimo_lance_da_engine(3):=(65-dd-((64-dd)/8)*8);
    ultimo_lance_da_engine(4):=9-((64-dd)/8+1);	
  end if;
else --pessoa com preta.
  if virado=false then
    ultimo_lance_da_engine(1):=(65-cc-((64-cc)/8)*8); --Aqui o /8 da a divisao inteira!!!
    ultimo_lance_da_engine(2):=9-((64-cc)/8+1);
    ultimo_lance_da_engine(3):=(65-dd-((64-dd)/8)*8);
    ultimo_lance_da_engine(4):=9-((64-dd)/8+1);
  else
    ultimo_lance_da_engine(1):=9-(65-cc-((64-cc)/8)*8); --Aqui o /8 da a divisao inteira!!!
    ultimo_lance_da_engine(2):=((64-cc)/8+1);
    ultimo_lance_da_engine(3):=9-(65-dd-((64-dd)/8)*8);
    ultimo_lance_da_engine(4):=((64-dd)/8+1);	
  end if;
end if;



daengine;

--Agora vou ver se dei xeque mate.
Matenele; --Executa o procedimento mate nele.

end loop; --Fim do Loop A

end prechess;





