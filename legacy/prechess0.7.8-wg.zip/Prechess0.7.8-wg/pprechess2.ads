package pprechess2 is


--relacionado a pequena abertura implementada.
numero_de_meu_movimento: integer;  --prechess iguala isso a zero.

Exequemate,Jogada_PegaP,Jogada_AmeacaP,Jogada_PerdeP:array(1..64,1..64) of Boolean; -- Peao.
Jogada_PegaB,Jogada_AmeacaB,Jogada_PerdeB:array(1..64,1..64) of Boolean; --Bispo.
Jogada_PegaC,Jogada_AmeacaC,Jogada_PerdeC:array(1..64,1..64) of Boolean; --Cavalo.
Jogada_PegaT, Jogada_AmeacaT,Jogada_PerdeT:array(1..64,1..64) of Boolean; --Torre.
Jogada_PegaD,Jogada_AmeacaD,Jogada_PerdeD:array(1..64,1..64) of Boolean; --Dama.
Jogada_PegaR,Jogada_AmeacaR,Jogada_PerdeR:array(1..64,1..64) of Boolean; -- Rei.
Jogada_Promove_Maquina, Jogada_Promove_Humano:array(1..64,1..64) of Boolean;--Promo��o.
Expoem_A_Xeque,Alinha:array(1..64,1..64) of Boolean;
Comerei:array(1..64,1..64) of boolean;
Posicao_Do_Rei:Integer;
temporario1, Temporario2, temporario3, temporario4: integer;
temporario5, Temporario6: integer;
Soma0L,Soma1L,Soma2L,Soma3L:Integer;

Contagem_Empate:integer:=0;
Somatoria_tabuleiro:Integer;
Perigo_Empate:Boolean;
Zerar_Contagem_Empate:Boolean;
Somar_Contagem_Empate:Boolean;

BackupPeao:Boolean;

MataEle2:array(1..64,1..64) of Boolean; --Quando der true a jogada acaba com ele.
Posicao_Do_Rei_Dele:Integer;

Lance_Do_Jogo: Integer; --Serve para dar ideia do momento do jogo em que estamos.
--Por exemplo, no inicio cavalo vai valer mais que bispo.
--No fim, se houver pelo menos dois bispos, um bispo vai valer mais que um cavalo.

Numero_B_Inimigo, Numero_B_Meu: Integer; --Para contar o n. de bispos para o proposito acima referido.

Ingles:Boolean:=False;

cc,dd:integer:=1;

 procedure Prechess2;

end pprechess2;
